/*
 * setEnvironment.h
 *
 *  Created on: Oct 11, 2013
 *      Author: cs1120239
 */

#ifndef SETENVIRONMENT_H_
#define SETENVIRONMENT_H_
#include <vector>
#include <string>
using namespace std;

//extracts the tokens of the string s splitted by delim
vector<string> extractTokens(string s , string delim);

//parses the input file
void parseInputFile(string inputFile);


#endif /* SETENVIRONMENT_H_ */
