/*
 * generateStudent.h
 *
 *  Created on: Oct 12, 2013
 *      Author: cs1120239
 */

#ifndef GENERATESTUDENT_H_
#define GENERATESTUDENT_H_

void initRandomStud();								//initiate the random
void* initGenerateStudent(void*);


#endif /* GENERATESTUDENT_H_ */
