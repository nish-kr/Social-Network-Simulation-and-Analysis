ipcrm -Q 121
ipcrm -Q 141