/*
 * Questions.cpp
 *
 *  Created on: Nov 11, 2013
 *      Author: cs1120250
 */

# include "Questions.h"
# include <vector>
#include <sstream>

#include "Dijkstra.h"				//delete both the header file and make a new header file
#include "FloydWar.h"
//#include "Network.h"

extern Graph N;

using namespace std;

extern int maxSort;
extern int start;
extern int end;
extern string spTyp;


//int* R,P,X;
//int tempL;
//Node *curNod;
//bool found;

vector<Node*> tempGr;

//bool isempty(){
//	bool F = true;
//	for(int i = 0; i< tempL;i++){
//		if(P[i]!=0 && X!=0){
//			F = false;
//		}
//	}
//	return  F;
//}

//void BronKer(){
//	if (!isempty()){
//	found = true;
//	}
//	if(!found ){
//
//		for(int j = 0; j<tempL;j++ ){
//			int tP[tempL];
//			int tX[tempL];
//			for (int i = 0; i< tempL; i++){
//				tP[i] = P[i];
//				tX[i] = X[i];
//			}
//
//
//		}
//	}
//}

bool isClique(){
	bool isCl = true;
	for(int i=0;i<tempGr.size();i++){
		for(int j = 0;j<tempGr.size();j++){
			if(i == j){continue;}
			if(!tempGr[i]->chkNode(tempGr[j]->name)){
				isCl = false;
				break;
			}
			if(!isCl){break;}
		}
		if(!isCl){break;}
	}
	return isCl;
}


int clqMax(Node* nod){
	for(int i = 0;i<nod->neighbours.size();i++){
		Node* cur = nod->neighbours[i];
		bool toPut =false;
		for(int j = 0;j<nod->neighbours.size();j++){
			if(i == j) continue;
			if( cur->chkNode(nod->neighbours[j]->name)){
				toPut = true;
				break;
			}
		}
		if(toPut) tempGr.push_back(cur);
	}







}

string QuesOne(string s){
//	curNod = N.searchNode(s);
//	tempL = N.searchNode(s)->neighbours.size();

















}

string QuesTwo(string s1, string s2){
	vector<Node*> T = dijk(s1,s2,N);
	int temp = T.size();
	if(temp == 0){
		return "NO such path exists";
	}
	else{
		temp--;
		ostringstream ostr;
		ostr << temp;
		string th = ostr.str();
		return  th;
	}
}



string QuesThree(string s1, string s2){
	vector<Node*> T = dijk(s1,s2,N);
	int temp = T.size();
	if(temp == 0||temp == 1){
			return "NO such path exists";
	}

	string s = "";
	for(int i = 1; i<temp-1;i++){
		s = s + T[i]->name + "\n" ;
	}
	return s;

//	s = route(s1,s2);
//	return s;
}

string QuesFour(){
	string s1;
	string s2;
	string res;
	if(spTyp == "student"){
		s1 =N.student[start]->name;
		s2 = N.student[end]->name;
		ostringstream ostr;
		ostr << maxSort;
		string th = ostr.str();
		res =  "path length:" + th +"\n";
		res = res + QuesThree(s1,s2);
	}
	else{
			s1 =N.faculty[start]->name;
			s2 = N.faculty[end]->name;
			ostringstream ostr;
			ostr << maxSort;
			string th = ostr.str();
			res =  "path length:" + th +"\n";
			res = res + QuesThree(s1,s2);

	}
	return res;



}


string QuesFive(string s){
		int temp = N.searchNode(s)->imp;
		ostringstream ostr;
		ostr << temp;
		string th = ostr.str();
		return th;

}

string QuesSix(string s){
		Node* nod = N.searchNode(s);
		int temp = nod->imp;
		bool first = true;
		string retS = "";

		for(int i = 0; i<nod->neighbours.size();i++){
			Node* curNod = nod->neighbours[i];
			if(temp< curNod->imp){
				if(first){
					retS = "yes \n" ;
				}
				retS = retS + curNod->name +"\n";
			}
		}
		return retS;
}

