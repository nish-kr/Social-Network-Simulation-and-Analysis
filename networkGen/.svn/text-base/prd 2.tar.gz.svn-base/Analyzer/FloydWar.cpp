/*
 * FloydWar.cpp
 *
 *  Created on: Nov 9, 2013
 *      Author: cs1120250
 */


#include "FloydWar.h"
#include "Network.h"
#include <iostream>
using namespace std;

extern int INF;
extern Graph N;

//extern int facPathArr[N.faculty.size()][N.faculty.size()];
//extern int studPathArr[N.student.size()][N.student.size()];
//
extern int **facPathArr;
extern int **studPathArr;

extern int **facGrArr;
extern int **studGrArr;

extern int **facDistArr;
extern int **studDistArr;
//
extern int maxSort;
extern int start;
extern int end;
extern string spTyp;




void flWr(){

	//starting from here the array of distances
	//is created for the faculty

	int lenF = N.faculty.size();
	int tempFArr[lenF][lenF], FDistArr[lenF][lenF], i,j ,k;

	int FpathArr[lenF][lenF];

								//tempFArr is the graph in matrix format
								//FDistArr is the shortest path distance in graph array
								//FpathArr what comes in shortest path
	maxSort =1;
	for(int i=0; i<lenF;i++){
		string s1 = N.faculty[i]->name;
		for(int j=0;j<lenF;j++){
			string s2 = N.faculty[j]->name;
			bool find = N.chkEdg(s1,s2);


			FpathArr[i][j] = -1;

			if(find){
				tempFArr[i][j] = 1;
				FDistArr[i][j] =  tempFArr[i][j];
			}
			else{
				tempFArr[i][j] = INF;
				FDistArr[i][j] = INF;
			}

			if(i==j){
				tempFArr[i][j] = 0;
				FDistArr[i][j] = 0;
			}
		}
	}

	for (k = 0; k < lenF; k++){
		for (i = 0; i < lenF; i++){
			for (j = 0; j < lenF; j++){
				if (FDistArr[i][k] + FDistArr[k][j] < FDistArr[i][j]){
				FDistArr[i][j] = FDistArr[i][k] + FDistArr[k][j];
				//N.faculty[k]->imp++;
				FpathArr[i][j] = k;
				}

			}
		}
	}

	for(i=0;i<lenF;i++){
		for(j=0;j<lenF;j++){
			facDistArr[i][j] =FDistArr[i][j];
			facGrArr[i][j] =tempFArr[i][j];
			facPathArr[i][j] = FpathArr[i][j];
			if (maxSort < FDistArr[i][j] && FDistArr[i][j] < INF ){											//this loop gives the largest
				maxSort = FDistArr[i][j];																	// short path
				start = i;
				end = j;
				spTyp = "faculty";
			}
		}
	}




	//starting from here the array of distances
	//is created for the student


	int lenS = N.student.size();
	int tempSArr[lenS][lenS], SDistArr[lenS][lenS];

	int SpathArr[lenS][lenS];

	for(int i=0; i<lenS;i++){
			string s1 = N.student[i]->name;
			for(int j=0;j<lenS;j++){
				string s2 = N.student[j]->name;

				SpathArr[i][j] = -1;

				bool find = N.chkEdg(s1,s2);
				if(find){
					tempSArr[i][j] = 1;
					SDistArr[i][j] =  tempSArr[i][j];
				}
				else{
					tempSArr[i][j] = INF;
					SDistArr[i][j] = INF;
				}
				if(i==j){
					tempSArr[i][j] = 0;
					SDistArr[i][j] = 0;
				}

			}
		}

		for (k = 0; k < lenS; k++){
			for (i = 0; i < lenS; i++){
				for (j = 0; j < lenS; j++){
					if (SDistArr[i][k] + SDistArr[k][j] < SDistArr[i][j]){
					SDistArr[i][j] = SDistArr[i][k] + SDistArr[k][j];
				//	N.student[k]->imp++;

					SpathArr[i][j] = k;						//write thr prev in the array

					}

				}
			}
		}

		for(i=0;i<lenS;i++){
				for(j=0;j<lenS;j++){
					studDistArr[i][j] =SDistArr[i][j];
					studGrArr[i][j] =tempSArr[i][j];
					studPathArr[i][j] = SpathArr[i][j];
					if (maxSort < SDistArr[i][j] && SDistArr[i][j] < INF ){											//this loop gives the largest
						maxSort = SDistArr[i][j];																	// short path
						start = i;
						end = j;
						spTyp = "student";
					}
				}
			}


	}







void Spath(int i,int j){
	if(studPathArr[i][j] == -1 || i==j){

	}
	else{
		int k = studPathArr[i][j];
		N.student[k]->imp++ ;
		Spath(i,k);

		//create the vector of path
		//Node* P = N.student[k];
		Spath(k,j);
	}
}

void Fpath(int i,int j){
	if(facPathArr[i][j] == -1|| i==j){

	}
	else{
		int k = facPathArr[i][j];
	//	Node* P = N.faculty[k];								//insert this node into the path vector
		N.faculty[k]->imp++ ;
		Fpath(i,k);
		Fpath(k,j);
	}
}

string route(string s1, string s2){
	int i = s1.find_first_of("_");
	char c = s1[i+1];
	if (c=='f'){
		i = N.indexNode(s1);
		int j = N.indexNode(s2);

			if(facPathArr[i][j] == -1 ){
				if(!N.chkEdg(N.faculty[i]->name,N.faculty[j]->name) && i!=j){
					return " no existent graph";
				}

				//cout<<i <<j;
				return " ";
			}
			else{
				int k = facPathArr[i][j];
				string a = N.faculty[k]->name;
				string b = route(s1,a);
				string c =  route(a,s2);
				if(b.compare("no existent route") == 0 || c.compare("no existent route") == 0 ){
					return "no existent route";
			}
				return b+" " +a + " " + c;
		}

	}
	else {
		i = N.indexNode(s1);
		int j = N.indexNode(s2);
			if(studPathArr[i][j] == -1 ){
				if(!N.chkEdg(N.student[i]->name,N.student[j]->name) && i!=j){
									return " no existent graph";
								}
				return " ";
			}
			else{
				int k = studPathArr[i][j];
				string a = N.student[k]->name;
				string b = route(s1,a);
				string c =  route(a,s2);
				if(b.compare("no existent route") == 0 || c.compare("no existent route") == 0 ){
					return "no existent route";
			}
				return b+" " +a + " " + c;
		}

	}
}

void impCal(){
	//cout<<1<<endl;
	for(int i = 0; i<N.faculty.size();i++){
		//cout<<2<<endl;
		for(int j = 0; j< N.faculty.size();j++){
			//cout<<3<< "  "<< i<< " " <<j<<endl;
			Fpath(i,j);
		}
	}
	for(int i = 0; i<N.student.size();i++){
		//cout<<4<<endl;
		for(int j = 0; j< N.student.size();j++){
		//	cout<<5<< "  "<< i<< " " <<j<<endl;
			Spath(i,j);
		}
	}
}





