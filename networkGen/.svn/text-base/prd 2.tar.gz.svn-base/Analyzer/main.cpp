/*
 * main.cpp
 *
 *  Created on: Nov 8, 2013
 *      Author: cs1120250
 */


#include <string>
#include <vector>
#include <queue>
#include <cstdlib>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <queue>
#include "Network.h"
#include "Dijkstra.h"
#include "FloydWar.h"
#include "Questions.h"
#include "parser.h"


int INF = 10000000;
Graph N;
//int facPathArr[N.faculty.size()][N.faculty.size()];
//int studPathArr[N.student.size()][N.student.size()];

int **facGrArr;
int **studGrArr;

int **facDistArr;
int **studDistArr;

int **facPathArr;
int **studPathArr;

int maxSort;
int start;
int end;
string spTyp;


/*
int main(){



Node n1,n2,n3,n4,n5,n6,n7,n8,n9,n10;
n1 = Node("n1_f");
n2= Node("n2_f");
n3=	Node("n3_f");
n4= Node("n4_f");
n5= Node("n5_f");
n6= Node("n6_f");
n7= Node("n7_f");
n8= Node("n8_f");
n9= Node("n9_f");
n10= Node("n10_f");
n1.type="faculty";n2.type = "faculty";
n3.type="faculty";n4.type="faculty";
n5.type="faculty";n6.type="faculty";
n7.type="faculty";n8.type="faculty";
n9.type="faculty";n10.type="faculty";
vector<Node*> T ;

T.push_back(&n2);T.push_back(&n3);T.push_back(&n5);T.push_back(&n10);
n1.neighbours = T;
T.clear() ;

T.push_back(&n1);T.push_back(&n4);T.push_back(&n6);T.push_back(&n10);T.push_back(&n9);
n2.neighbours = T;
T.clear() ;

T.push_back(&n1);T.push_back(&n8);
n3.neighbours = T;
T.clear() ;

T.push_back(&n2);T.push_back(&n5);T.push_back(&n7);T.push_back(&n8);
n4.neighbours = T;
T.clear() ;

T.push_back(&n1);T.push_back(&n4);
n5.neighbours = T;
T.clear() ;

T.push_back(&n2);T.push_back(&n7);
n6.neighbours = T;
T.clear() ;

T.push_back(&n4);T.push_back(&n6);
n7.neighbours = T;
T.clear() ;

T.push_back(&n3);T.push_back(&n4);T.push_back(&n9);
n8.neighbours = T;
T.clear() ;

T.push_back(&n2);T.push_back(&n8);
n9.neighbours = T;
T.clear() ;

T.push_back(&n2);T.push_back(&n1);
n10.neighbours = T;
T.clear() ;

// graph n will be global which will be generated after parsing



T.push_back(&n1);T.push_back(&n4);T.push_back(&n6);T.push_back(&n10);T.push_back(&n9);
T.push_back(&n2);T.push_back(&n3);T.push_back(&n5);T.push_back(&n7);T.push_back(&n8);
N.faculty = T;

//
//T.clear() ;
//T = dijk("n1_f","n8_f",N);
//int len = T.size();
//for(int i = 0;i<len;i++){
//	cout<<T[i]->name<<endl;
//}
//
//	cout<<endl;
//
//T.clear();
//T = dijk("n3_f","n6_f",N);
//len = T.size();
//for(int i = 0;i<len;i++){
//	cout<<T[i]->name<< "  "<<T[i]->weight<<endl;
//
//}
//
//    cout<<endl;
//
//T.clear();
//T = dijk("n6_f","n6_f",N);
//len = T.size();
//for(int i = 0;i<len;i++){
//	cout<<T[i]->name<< "  "<<T[i]->weight<<endl;
//
//}
}
*/

void cleanUp(){
	int facSize = N.faculty.size();
	int studSize = N.student.size();
	for(int i=0;i<facSize;i++){
		delete[] facDistArr[i];
		delete[] facGrArr[i];
		delete[] facPathArr[i];
	}
	for(int i=0;i<studSize;i++){
		delete[] studDistArr[i];
		delete[] studGrArr[i];
		delete[] studPathArr[i];
	}
	//delete the network
}

int main(){
	parseGraphML("graph.graphml");
	/*for(int i=0;i<N.student.size();i++){
		cout<<N.student[i]->name<<" "<<N.student[i]->imp<<" "<<N.student[i]->state<<" "<<N.student[i]->type<<" "
				<<N.student[i]->weight<<endl;
	}
	for(int i=0;i<N.sEdg.size();i++){
		cout<<N.sEdg[i]->type<<" "<<N.sEdg[i]->source->name<<" "<<N.sEdg[i]->target->name<<endl;
	}*/

	int facSize = N.faculty.size();
	int studSize = N.student.size();
	facGrArr = new int*[facSize];
	facDistArr = new int*[facSize];
	facPathArr = new int*[facSize];
	studDistArr = new int*[studSize];
	studGrArr = new int*[studSize];
	studPathArr = new int*[studSize];
	for(int i=0;i<facSize;i++){
		facDistArr[i] = new int[facSize];
		facGrArr[i] = new int[facSize];
		facPathArr[i] = new int[facSize];
	}
	for(int i=0;i<studSize;i++){
		studDistArr[i] = new int[studSize];
		studGrArr[i] = new int[studSize];
		studPathArr[i] = new int[studSize];
	}
//	vector<Node*> v = dijk("IITD_f_38" , "IITD_f_1" ,N);
//	if (v.size() == 0) cout<<"size 0"<<endl;
//	else{
//		for(int i=0;i<v.size();i++){
//			cout<<v[i]->name<<endl;
//		}
//	}

	flWr();
//	for(int i=0;i<50;i++){
//		for(int j=0;j<50;j++){
//
//			cout<< facDistArr[i][j] << " ";
////			cout<< facGrArr[i][j]	<<" ";
////			cout<< facPathArr[i][j]<< " " ;
//		}
//		cout<< endl;
//	}
 impCal();
 //for(int i=0;i<N.student.size();i++){
 //		cout<<N.student[i]->name<<" "<<N.student[i]->imp<<endl;
 //	}

//	cout<< route("IITD_s_236" , "IITD_s_226")<<endl;




}
