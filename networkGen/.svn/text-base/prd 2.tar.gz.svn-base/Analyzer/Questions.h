/*
 * Questions.h
 *
 *  Created on: Nov 11, 2013
 *      Author: cs1120250
 */

#ifndef QUESTIONS_H_
#define QUESTIONS_H_

#include <string>
using namespace std;

bool isempty();
bool isClique();
string QuesOne(string s);
string QuesTwo(string s1,string s2);
string QuesThree(string s1, string s2);
string QuesFour(string s1, string s2);
string QuesFive(string s1);
string QuesSix(string s);


#endif /* QUESTIONS_H_ */
