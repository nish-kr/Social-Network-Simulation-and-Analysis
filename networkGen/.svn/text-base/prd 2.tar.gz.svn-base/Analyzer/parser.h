/*
 * parser.h
 *
 *  Created on: Nov 11, 2013
 *      Author: cs1120239
 */

#ifndef PARSER_H_
#define PARSER_H_
#include <string>
using namespace std;

void parseGraphML(string);


#endif /* PARSER_H_ */
