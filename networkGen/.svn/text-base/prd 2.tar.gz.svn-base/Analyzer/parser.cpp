/*
 * parser.cpp
 *
 *  Created on: Nov 11, 2013
 *      Author: cs1120239
 */

#include "parser.h"
#include "Network.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <vector>
#include <cstring>
using namespace std;

extern Graph N;

//extracts the tokens of the string s splitted by delim
vector<string> extractTokens(string s , string delim){
	char arr[s.size()];
	strcpy(arr , s.c_str());
	const char* de = delim.c_str();
	char* te = strtok(arr, de);
	vector<string> toret;
	while(te!=NULL){
		toret.push_back(string((const char*) te));
		te = strtok(NULL , de );
	}
	return toret;
}

//tells is the given string is a faculty or a student : false for faculty and true for student
bool isFacorStud(string s){
	size_t x = s.find_first_of("_");
	if (x == string::npos) {cerr<<"Error Wrong argument to isFacorStud . Exiting .";exit(1);}
	char c = s[x+1];
	return (c=='s');
}


int giveID(string s){
	size_t x = s.find_last_of("_");
	string s1 = s.substr(x+1);
	return atoi(s1.c_str());
}


void parseGraphML(string inFile){
	ifstream in;
	in.open(inFile.c_str());
	if (!in.is_open()){
		cerr<<"Error reading graphML file .Exiting ."<<endl;
		exit(1);
	}
	vector<string> readLine;
	string temp;
	while(!in.eof()){
		getline(in , temp);
		if (temp.find_first_not_of(" \t\n\r") == string::npos){
			//first not of these chars is at end of string => string is made only of these chars
			continue;
		}
		readLine = extractTokens(temp , " \t\n\r/<>\"=");

		if ((readLine[0].compare("node") == 0) && (readLine[1].compare("id") == 0)){
			//is a line containing node id
			Node* n = new Node(readLine[2]);
			if (isFacorStud(readLine[2])){
				//means a student
				N.student.push_back(n);
			}
			else{
				//means a faculty
				N.faculty.push_back(n);
			}
		}
		else if ((readLine[0].compare("edge") == 0) && (readLine[1].compare("source") == 0)){
			//is a line containing edge info
			//assume all nodes have been created
			//also assume all nodes were added in the vector in serial order
			Edge* e = new Edge();
			if (isFacorStud(readLine[2])){
				//source is a student and hence target is also a student
				e->type = "student";
				int id1 = giveID(readLine[2]);
				int id2 = giveID(readLine[4]);
				Node* n1 = N.student[id1-1];
				Node* n2 = N.student[id2-1];
				n1->edges.push_back(e);
				n1->neighbours.push_back(n2);
				n2->edges.push_back(e);
				n2->neighbours.push_back(n1);
				e->source = n1;
				e->target = n2;
				N.sEdg.push_back(e);
			}
			else{
				//source is a faculty
				e->type = "faculty";
				int id1 = giveID(readLine[2]);
				int id2 = giveID(readLine[4]);
				Node* n1 = N.faculty[id1-1];
				Node* n2 = N.faculty[id2-1];
				n1->edges.push_back(e);
				n1->neighbours.push_back(n2);
				n2->edges.push_back(e);
				n2->neighbours.push_back(n1);
				e->source = n1;
				e->target = n2;
				N.fEdg.push_back(e);
			}
		}
	}
}

